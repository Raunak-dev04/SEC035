character = 'A'
# convert char to ASCII
char_ascii_no = ord(character)
for i in range(0, 5):
    for j in range(0, i + 1):
        # Convert the ASCII value to the character
        user_char = chr(char_ascii_no)
        print(user_char, end=' ')
    print()