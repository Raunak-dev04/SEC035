a = int(input("Enter the first number: "))
b = int(input("Enter the second number: "))
sum = a + b
print(f"The sum is: {sum}")
