person = {"name": "Alice", "age": 25, "city": "New York"}
print(person["name"])
